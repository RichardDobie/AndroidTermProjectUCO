package edu.uco.rdobie.myzombiepet;

public class Constants {
		public static final String BROADCAST_ACTION = "edu.uco.rdobie.myzombiepet.BROADCAST";
		
		public static final String EXTENDED_DATA_STATUS = "edu.uco.rdobie.myzombiepet.STATUS";
}
